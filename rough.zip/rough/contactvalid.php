<?php
    session_start();
    $message_sent=false;
    if(isset($_POST['email']) && $_POST['email']!='')
    {
        if( filter_var($_POST['email'],FILTER_VALIDATE_EMAIl) )
        {
            $username=$_POST['name'];
            $userEmail=$_POST['email'];
            $messageSubject=$_POST['subject'];
            $message=$_POST['message'];
            $to="pritishkannanbss@gmail.com";
            $body="";
            $body="From: ".$username."\r\n";
            $body="From: ".$userEmail."\r\n";
            $body="From: ".$messageSubject."\r\n";
            $body="From: ".$message."\r\n";
            mail($to,$messageSubject,$body);
            $message_sent=true;
        }
    }
    else
    {
        $invalid_class_name="form-invalid";
    }
?>