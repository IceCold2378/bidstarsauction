<?php 

$conn= new mysqli('localhost:3306','root','','bidstars')or die("Could not connect to mysql".mysqli_error($con));
